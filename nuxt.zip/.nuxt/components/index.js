export const Button = () => import('../../components/Button.vue' /* webpackChunkName: "components/button" */).then(c => wrapFunctional(c.default || c))
export const Card = () => import('../../components/Card.vue' /* webpackChunkName: "components/card" */).then(c => wrapFunctional(c.default || c))
export const Header = () => import('../../components/Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const Input = () => import('../../components/Input.vue' /* webpackChunkName: "components/input" */).then(c => wrapFunctional(c.default || c))
export const Logout = () => import('../../components/Logout.vue' /* webpackChunkName: "components/logout" */).then(c => wrapFunctional(c.default || c))
export const Navbar = () => import('../../components/Navbar.vue' /* webpackChunkName: "components/navbar" */).then(c => wrapFunctional(c.default || c))
export const NavbarLink = () => import('../../components/NavbarLink.vue' /* webpackChunkName: "components/navbar-link" */).then(c => wrapFunctional(c.default || c))
export const NewPost = () => import('../../components/NewPost.vue' /* webpackChunkName: "components/new-post" */).then(c => wrapFunctional(c.default || c))
export const NewProject = () => import('../../components/NewProject.vue' /* webpackChunkName: "components/new-project" */).then(c => wrapFunctional(c.default || c))
export const NewResource = () => import('../../components/NewResource.vue' /* webpackChunkName: "components/new-resource" */).then(c => wrapFunctional(c.default || c))
export const Post = () => import('../../components/Post.vue' /* webpackChunkName: "components/post" */).then(c => wrapFunctional(c.default || c))
export const PostPreview = () => import('../../components/PostPreview.vue' /* webpackChunkName: "components/post-preview" */).then(c => wrapFunctional(c.default || c))
export const Project = () => import('../../components/Project.vue' /* webpackChunkName: "components/project" */).then(c => wrapFunctional(c.default || c))
export const ProjectList = () => import('../../components/ProjectList.vue' /* webpackChunkName: "components/project-list" */).then(c => wrapFunctional(c.default || c))
export const Resource = () => import('../../components/Resource.vue' /* webpackChunkName: "components/resource" */).then(c => wrapFunctional(c.default || c))
export const Tag = () => import('../../components/Tag.vue' /* webpackChunkName: "components/tag" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
